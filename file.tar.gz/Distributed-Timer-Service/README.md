# Distributed-Timer-Service
Tencent Q-Learning Project

descriptions in power point


[paxos](https://github.com/tangwz/paxos/tree/rpc)

[timewheel](https://github.com/lk668/timewheel)

[为什么mutex不用*](http://www.51hsw.com/golang-map-bing-fa-suo-wen-ti/)
无效的内存地址，是因为在使用的时候，只取了地址，但是地址并未初始化，所以会报nil
